package com.hyscaler.cms.security;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
    @Autowired
    private JWTUtils jwtUtils;
    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        //Authorization
        String requestHeader = request.getHeader("Authorization");
        log.info("Header:: {}", requestHeader);
        String token = null;
        String username = null;
        if (!ObjectUtils.isEmpty(requestHeader) && requestHeader.startsWith("Bearer")) {
            token = requestHeader.substring(7);
            try {
                username = this.jwtUtils.getUsernameFromToken(token);//Get Username from Token
            } catch (IllegalArgumentException e) {
                log.error("Illegal Argument while fetching the username !!");
            } catch (ExpiredJwtException e) {
            	log.error("Given jwt token is expired !!");
            } catch (MalformedJwtException e) {
            	log.error("Wrong Modification has done in token !! Invalid Token");
            } catch (Exception e) {
            	log.error("Error: {}", e.getMessage());
            }
        } else {
        	log.error("Invalid RequestHeader !!");
        }
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            //Fetch userdetail from username
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
            Boolean validateToken = this.jwtUtils.validateToken(token, userDetails);
            if (validateToken) {
                //Set the authentication
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authentication);
            } else {
            	log.error("Validation fails !!");
            }
        }
        filterChain.doFilter(request, response);
    }
}