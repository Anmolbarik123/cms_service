package com.hyscaler.cms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hyscaler.cms.models.Property;

public interface PropertyRepository extends JpaRepository<Property, Integer> {

}
