package com.hyscaler.cms.endpoints;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.hyscaler.cms.commons.CommonUtil;
import com.hyscaler.cms.dto.UserDto;

public interface CMSUserEndpoint {

	@GetMapping("/getUser")
	@PreAuthorize(CommonUtil.ROLE_ADMIN)
	public ResponseEntity<UserDto> getUserById(@RequestParam Integer userId);

	@GetMapping("/getAllUsers")
	@PreAuthorize(CommonUtil.ROLE_ADMIN)
	public ResponseEntity<List<UserDto>> getUsers();

	@PostMapping("/save")
	@PreAuthorize(CommonUtil.ROLE_USER)
	public ResponseEntity<UserDto> saveUser(@RequestBody UserDto userDto);

	@PutMapping("/update")
	@PreAuthorize(CommonUtil.ROLE_USER)
	public ResponseEntity<UserDto> updateUserDetails(@RequestParam Integer userId, @RequestBody UserDto userDto);

	@DeleteMapping
	@PreAuthorize(CommonUtil.ROLE_ADMIN)
	public void removeUser(@RequestParam Integer userId);
}
