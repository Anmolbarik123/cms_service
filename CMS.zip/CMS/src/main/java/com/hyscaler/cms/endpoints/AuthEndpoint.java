package com.hyscaler.cms.endpoints;

import com.hyscaler.cms.dto.JWTRequest;
import com.hyscaler.cms.dto.JWTResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;

public interface AuthEndpoint {

    @PostMapping
    public ResponseEntity<JWTResponse> login(JWTRequest request);
}
