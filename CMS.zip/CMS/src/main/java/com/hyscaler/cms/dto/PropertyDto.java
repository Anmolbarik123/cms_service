package com.hyscaler.cms.dto;

public class PropertyDto {

	private Integer id;
	private String name;
	private Double price;
	private String location;
	private String description;
	private byte[] photo;

	public PropertyDto() {
		super();
	}

	public PropertyDto(Integer id, String name, Double price, String location, String description, byte[] photo) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.location = location;
		this.description = description;
		this.photo = photo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
}
