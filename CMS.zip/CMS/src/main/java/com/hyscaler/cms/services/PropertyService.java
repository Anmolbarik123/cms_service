package com.hyscaler.cms.services;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.hyscaler.cms.dto.PropertyDto;
import com.hyscaler.cms.models.Property;
import com.hyscaler.cms.repositories.PropertyRepository;

@Service
public class PropertyService {

	@Autowired
	private PropertyRepository propertyRepository;
	public static List<PropertyDto> props = Arrays.asList(new PropertyDto(1, "Plaza", 500000.0, "BBSR", "New Flat", null),
			new PropertyDto(2, "MS Plaza", 800000.0, "BBSR", "FF Flat", null),
			new PropertyDto(3, "Villa", 1500000.0, "BBSR", "New Flat", null));

	public PropertyDto saveProperty(PropertyDto propertyDto) {
		if (!ObjectUtils.isEmpty(propertyDto)) {
			Property property = new Property();
			BeanUtils.copyProperties(propertyDto, property);
			propertyRepository.saveAndFlush(property);
		}
		return propertyDto;
	}

	public PropertyDto getPropertyById(Integer userId) {
		PropertyDto propertyDto = null;
		if (!ObjectUtils.isEmpty(userId)) {
			Optional<Property> optProperty = propertyRepository.findById(userId);
			if (optProperty.isPresent()) {
				Property property = optProperty.get();
				BeanUtils.copyProperties(property, propertyDto);
			}
		}
		return propertyDto;
	}

	public List<PropertyDto> getProperties() {
		List<Property> properties = propertyRepository.findAll();
		List<PropertyDto> propertyDtos = properties.parallelStream().map(p -> new PropertyDto(p.getId(), p.getName(),
				p.getPrice(), p.getLocation(), p.getDescription(), p.getPhoto())).collect(Collectors.toList());
//		return propertyDtos;
		return props;
	}
}
