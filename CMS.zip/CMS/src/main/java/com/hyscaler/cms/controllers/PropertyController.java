package com.hyscaler.cms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hyscaler.cms.dto.PropertyDto;
import com.hyscaler.cms.endpoints.PropertyEndpoint;
import com.hyscaler.cms.services.PropertyService;


@CrossOrigin
@RestController
@RequestMapping(value = {"/cms/api/v1/property"})
public class PropertyController implements PropertyEndpoint {

	@Autowired
	private PropertyService propertyService;

	@Override
	public ResponseEntity<PropertyDto> saveProperty(PropertyDto propertyDto) {
		PropertyDto property = propertyService.saveProperty(propertyDto);
		if (!ObjectUtils.isEmpty(property)) {
			return ResponseEntity.ok(property);
		} else {
			return new ResponseEntity<PropertyDto>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public ResponseEntity<PropertyDto> getPropertyById(Integer userId) {
		PropertyDto propertyDto = propertyService.getPropertyById(userId);
		if (!ObjectUtils.isEmpty(propertyDto)) {
			return ResponseEntity.ok(propertyDto);
		} else {
			return new ResponseEntity<PropertyDto>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public ResponseEntity<List<PropertyDto>> getProperties() {
		List<PropertyDto> properties = propertyService.getProperties();
		if (!CollectionUtils.isEmpty(properties)) {
			return ResponseEntity.ok(properties);
		} else {
			return new ResponseEntity<List<PropertyDto>>(HttpStatusCode.valueOf(204));
		}
	}

}
