package com.hyscaler.cms.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.hyscaler.cms.dto.UserDto;
import com.hyscaler.cms.models.CMSUser;
import com.hyscaler.cms.repositories.CMSUserRepository;

@Service
public class CMSUserService {

	@Autowired
	private CMSUserRepository cmsUserRepository;

	public UserDto getUserById(Integer userId) {
		UserDto userDto = null;
		Optional<CMSUser> optUser = cmsUserRepository.findById(userId);
		if (optUser.isPresent()) {
			CMSUser cmsUser = optUser.get();
			BeanUtils.copyProperties(cmsUser, userDto);
		}
		return userDto;
	}

	public List<UserDto> getUsers() {
		List<CMSUser> users = cmsUserRepository.findAll();
		List<UserDto> userDtos = users.parallelStream()
				.map(u -> new UserDto(u.getId(), u.getUserId(), u.getPassword(), u.getRole()))
				.collect(Collectors.toList());
		return userDtos;
	}

	public UserDto saveUser(UserDto userDto) {
		if (!ObjectUtils.isEmpty(userDto)) {
			CMSUser cmsUser = new CMSUser();
			BeanUtils.copyProperties(userDto, cmsUser);
			cmsUserRepository.saveAndFlush(cmsUser);
		}
		return userDto;
	}

	public UserDto updateUserDetails(Integer userId, UserDto userDto) {
		if (!ObjectUtils.isEmpty(userId)) {
			Optional<CMSUser> optUser = cmsUserRepository.findById(userId);
			if (optUser.isPresent()) {
				CMSUser cmsUserNew = new CMSUser();
				BeanUtils.copyProperties(userDto, cmsUserNew);
				CMSUser cmsUserOld = optUser.get();
				BeanUtils.copyProperties(cmsUserNew, cmsUserOld);
				cmsUserRepository.saveAndFlush(cmsUserOld);
			}
		}
		return userDto;
	}

	public void removeUser(Integer userId) {
		if (!ObjectUtils.isEmpty(userId)) {
			cmsUserRepository.deleteById(userId);
		}
	}

}
