package com.hyscaler.cms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hyscaler.cms.dto.UserDto;
import com.hyscaler.cms.endpoints.CMSUserEndpoint;
import com.hyscaler.cms.services.CMSUserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping(value = {"/cms/api/v1/cmsuser"})
public class CMSUserController implements CMSUserEndpoint {

	@Autowired
	private CMSUserService cmsUserService;

	@Override
	public ResponseEntity<UserDto> getUserById(Integer userId) {
		UserDto userDto = cmsUserService.getUserById(userId);
		if (!ObjectUtils.isEmpty(userDto)) {
			return ResponseEntity.ok(userDto);
		} else {
			return new ResponseEntity<UserDto>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public ResponseEntity<List<UserDto>> getUsers() {
		List<UserDto> users = cmsUserService.getUsers();
		if (!CollectionUtils.isEmpty(users)) {
			return ResponseEntity.ok(users);
		} else {
			log.error(null);
			return new ResponseEntity<List<UserDto>>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public ResponseEntity<UserDto> saveUser(UserDto userDto) {
		UserDto user = cmsUserService.saveUser(userDto);
		if (!ObjectUtils.isEmpty(user)) {
			return ResponseEntity.ok(user);
		} else {
			return new ResponseEntity<UserDto>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public ResponseEntity<UserDto> updateUserDetails(Integer userId, UserDto userDto) {
		UserDto userDetails = cmsUserService.updateUserDetails(userId, userDto);
		if (!ObjectUtils.isEmpty(userDetails)) {
			return ResponseEntity.ok(userDetails);
		} else {
			return new ResponseEntity<UserDto>(HttpStatusCode.valueOf(204));
		}
	}

	@Override
	public void removeUser(Integer userId) {
		cmsUserService.removeUser(userId);
	}
}
