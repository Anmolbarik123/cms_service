package com.hyscaler.cms.commons;

public interface CommonUtil {
	
	public static final String ROLE_ADMIN = "hasRole('CMS_ADMIN')";
	public static final String ROLE_USER = "hasRole('CMS_USER')";

}
