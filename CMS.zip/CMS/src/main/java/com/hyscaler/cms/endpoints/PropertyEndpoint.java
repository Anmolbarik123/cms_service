package com.hyscaler.cms.endpoints;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.hyscaler.cms.commons.CommonUtil;
import com.hyscaler.cms.dto.PropertyDto;

public interface PropertyEndpoint {

	@PostMapping
	@PreAuthorize(CommonUtil.ROLE_ADMIN)
	public ResponseEntity<PropertyDto> saveProperty(@RequestBody PropertyDto propertyDto);

	@GetMapping("/getAllProperties")
	@PreAuthorize(CommonUtil.ROLE_USER)
	public ResponseEntity<List<PropertyDto>> getProperties();

	@GetMapping("/getProperty")
	@PreAuthorize(CommonUtil.ROLE_USER)
	public ResponseEntity<PropertyDto> getPropertyById(@RequestParam Integer userId);

}
