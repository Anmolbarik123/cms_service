package com.hyscaler.cms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hyscaler.cms.models.CMSUser;

public interface CMSUserRepository extends JpaRepository<CMSUser, Integer> {

}
